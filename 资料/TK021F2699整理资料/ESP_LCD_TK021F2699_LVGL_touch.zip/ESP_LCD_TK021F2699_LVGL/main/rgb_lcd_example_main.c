/*
 * SPDX-FileCopyrightText: 2022-2023 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: CC0-1.0
 */

#include <stdio.h>
#include "sdkconfig.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "esp_timer.h"
#include "esp_lcd_panel_ops.h"
#include "esp_lcd_panel_rgb.h"
#include "esp_check.h"
#include "driver/gpio.h"
#include "driver/i2c_master.h"
#include "esp_err.h"
#include "esp_log.h"
#include "lvgl.h"

#include "LCD.h"
#include "led_ws2812.h"
#include "esp32wifi.h"


static const char *TAG = "example";

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////// Please update the following configuration according to your LCD spec //////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define EXAMPLE_LCD_PIXEL_CLOCK_HZ     (16 * 1000 * 1000)
#define EXAMPLE_LCD_BK_LIGHT_ON_LEVEL  -1
#define EXAMPLE_LCD_BK_LIGHT_OFF_LEVEL !EXAMPLE_LCD_BK_LIGHT_ON_LEVEL
#define EXAMPLE_PIN_NUM_BK_LIGHT       -1
#define EXAMPLE_PIN_NUM_HSYNC          41
#define EXAMPLE_PIN_NUM_VSYNC          46   
#define EXAMPLE_PIN_NUM_DE             42
#define EXAMPLE_PIN_NUM_PCLK           2

#define EXAMPLE_PIN_NUM_DATA0          4 // B0
#define EXAMPLE_PIN_NUM_DATA1          5 // B1
#define EXAMPLE_PIN_NUM_DATA2          6 // B2
#define EXAMPLE_PIN_NUM_DATA3          7 // B3
#define EXAMPLE_PIN_NUM_DATA4          15 // B4
#define EXAMPLE_PIN_NUM_DATA5          16 // G0
#define EXAMPLE_PIN_NUM_DATA6          17 // G1
#define EXAMPLE_PIN_NUM_DATA7          18 // G2
#define EXAMPLE_PIN_NUM_DATA8          9 // G3
#define EXAMPLE_PIN_NUM_DATA9          10 // G4
#define EXAMPLE_PIN_NUM_DATA10         11 // G5
#define EXAMPLE_PIN_NUM_DATA11         0  // R0
#define EXAMPLE_PIN_NUM_DATA12         45  // R1
#define EXAMPLE_PIN_NUM_DATA13         48 // R2
#define EXAMPLE_PIN_NUM_DATA14         47 // R3
#define EXAMPLE_PIN_NUM_DATA15         21 // R4
#define EXAMPLE_PIN_NUM_DISP_EN        -1

// The pixel number in horizontal and vertical
#define EXAMPLE_LCD_H_RES              480
#define EXAMPLE_LCD_V_RES              480

#if CONFIG_EXAMPLE_DOUBLE_FB
#define EXAMPLE_LCD_NUM_FB             2
#else
#define EXAMPLE_LCD_NUM_FB             1
#endif // CONFIG_EXAMPLE_DOUBLE_FB

#define EXAMPLE_LVGL_TICK_PERIOD_MS    2
#define EXAMPLE_LVGL_TASK_MAX_DELAY_MS 500
#define EXAMPLE_LVGL_TASK_MIN_DELAY_MS 1
#define EXAMPLE_LVGL_TASK_STACK_SIZE   (4 * 1024)
#define EXAMPLE_LVGL_TASK_PRIORITY     2

static SemaphoreHandle_t lvgl_mux = NULL;
ws2812_strip_handle_t ws2812_handle = NULL;

// we use two semaphores to sync the VSYNC event and the LVGL task, to avoid potential tearing effect
#if CONFIG_EXAMPLE_AVOID_TEAR_EFFECT_WITH_SEM
SemaphoreHandle_t sem_vsync_end;
SemaphoreHandle_t sem_gui_ready;
#endif

extern void lvgl_demo_ui(lv_disp_t *disp);
extern void ui_gif_demo(void);

static bool example_on_vsync_event(esp_lcd_panel_handle_t panel, const esp_lcd_rgb_panel_event_data_t *event_data, void *user_data)
{
    BaseType_t high_task_awoken = pdFALSE;
#if CONFIG_EXAMPLE_AVOID_TEAR_EFFECT_WITH_SEM
    if (xSemaphoreTakeFromISR(sem_gui_ready, &high_task_awoken) == pdTRUE) {
        xSemaphoreGiveFromISR(sem_vsync_end, &high_task_awoken);
    }
#endif
    return high_task_awoken == pdTRUE;
}

static void example_lvgl_flush_cb(lv_disp_drv_t *drv, const lv_area_t *area, lv_color_t *color_map)
{
    esp_lcd_panel_handle_t panel_handle = (esp_lcd_panel_handle_t) drv->user_data;
    int offsetx1 = area->x1;
    int offsetx2 = area->x2;
    int offsety1 = area->y1;
    int offsety2 = area->y2;
#if CONFIG_EXAMPLE_AVOID_TEAR_EFFECT_WITH_SEM
    xSemaphoreGive(sem_gui_ready);
    xSemaphoreTake(sem_vsync_end, portMAX_DELAY);
#endif
    // pass the draw buffer to the driver
    esp_lcd_panel_draw_bitmap(panel_handle, offsetx1, offsety1, offsetx2 +1, offsety2+1, color_map);
    lv_disp_flush_ready(drv);
}

static void example_increase_lvgl_tick(void *arg)
{
    /* Tell LVGL how many milliseconds has elapsed */
    lv_tick_inc(EXAMPLE_LVGL_TICK_PERIOD_MS);
}

bool example_lvgl_lock(int timeout_ms)
{
    // Convert timeout in milliseconds to FreeRTOS ticks
    // If `timeout_ms` is set to -1, the program will block until the condition is met
    const TickType_t timeout_ticks = (timeout_ms == -1) ? portMAX_DELAY : pdMS_TO_TICKS(timeout_ms);
    return xSemaphoreTakeRecursive(lvgl_mux, timeout_ticks) == pdTRUE;
}

void example_lvgl_unlock(void)
{
    xSemaphoreGiveRecursive(lvgl_mux);
}

static void example_lvgl_port_task(void *arg)
{
    ESP_LOGI(TAG, "Starting LVGL task");
    uint32_t task_delay_ms = EXAMPLE_LVGL_TASK_MAX_DELAY_MS;
    while (1) {
        // Lock the mutex due to the LVGL APIs are not thread-safe
        if (example_lvgl_lock(-1)) {
            task_delay_ms = lv_timer_handler();
            // Release the mutex
            example_lvgl_unlock();
        }
        if (task_delay_ms > EXAMPLE_LVGL_TASK_MAX_DELAY_MS) {
            task_delay_ms = EXAMPLE_LVGL_TASK_MAX_DELAY_MS;
        } else if (task_delay_ms < EXAMPLE_LVGL_TASK_MIN_DELAY_MS) {
            task_delay_ms = EXAMPLE_LVGL_TASK_MIN_DELAY_MS;
        }
        vTaskDelay(pdMS_TO_TICKS(task_delay_ms));
    }
}

/************* 触摸 **************/
/* 触摸I2C通道 */
#define EXAMPLE_TOUCH_I2C_NUM       (0)
#define EXAMPLE_TOUCH_I2C_CLK_HZ    (400000)

/* 触摸引脚 */
#define EXAMPLE_TOUCH_I2C_SCL       (GPIO_NUM_13)
#define EXAMPLE_TOUCH_I2C_SDA       (GPIO_NUM_20)
#define EXAMPLE_TOUCH_GPIO_INT      (GPIO_NUM_8)

#define CPT_ADDR 0x58   //I2C地址

/* LCD Touch IO and panel */
i2c_master_bus_handle_t bus_handle;
i2c_master_dev_handle_t dev_handle;

/********************************/

static volatile bool touch_event_occurred = false;

/* 触摸初始化 */
static esp_err_t app_touch_init(void)
{
    i2c_master_bus_config_t i2c_bus_cfg = {
        .i2c_port = EXAMPLE_TOUCH_I2C_NUM,
        .sda_io_num = EXAMPLE_TOUCH_I2C_SDA,
        .scl_io_num = EXAMPLE_TOUCH_I2C_SCL,
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .glitch_ignore_cnt = 7,
        .intr_priority = 0,
        .trans_queue_depth = 0,
        .flags = {
            .enable_internal_pullup = 1,
        },
    };
    
    ESP_ERROR_CHECK(i2c_new_master_bus(&i2c_bus_cfg, &bus_handle));
    ESP_LOGI(TAG, "I2C master bus initialized");

        // 创建I2C设备配置
    i2c_device_config_t dev_cfg = {
        .dev_addr_length = I2C_ADDR_BIT_LEN_7,
        .device_address = CPT_ADDR,
        .scl_speed_hz = EXAMPLE_TOUCH_I2C_CLK_HZ,
    };
    
    
    esp_err_t ret = i2c_master_bus_add_device(bus_handle, &dev_cfg, &dev_handle);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to add I2C device: %s", esp_err_to_name(ret));
        return ret;
    }

    return ESP_OK;
}

// 中断处理函数
static void IRAM_ATTR touch_interrupt_handler(void *arg)
{
    touch_event_occurred = true;
}

// 初始化中断
static void init_touch_interrupt(void)
{
    // 配置中断引脚
    gpio_config_t io_conf = {
        .pin_bit_mask = (1ULL << EXAMPLE_TOUCH_GPIO_INT),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,  // 启用上拉（通常需要）
        .intr_type = GPIO_INTR_NEGEDGE,    // 下降沿触发（如果 .interrupt=0）
    };
    gpio_config(&io_conf);
    
    // 安装中断服务
    gpio_install_isr_service(0);
    gpio_isr_handler_add(EXAMPLE_TOUCH_GPIO_INT, touch_interrupt_handler, NULL);
}

static void example_lvgl_touch_cb(lv_indev_drv_t *drv, lv_indev_data_t *data)
{
    static uint8_t buf[10];
    static int GUI_Value_X = 0;
    static int GUI_Value_Y = 0;
    static int touchInfo_flag = 0;  

    // 只有在中断发生时才读取数据（降低CPU负载）    
    // if (touch_event_occurred)                //使用中断引脚可解除注释
    // {
        // 写入命令序列
        uint8_t write_data[4] = {0xD0, 0x07, 0x00, 0x00};
        esp_err_t ret = i2c_master_transmit(dev_handle, write_data, sizeof(write_data), -1);
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "Failed to write command: %s", esp_err_to_name(ret));
            i2c_master_bus_rm_device(dev_handle);
            return ;
        }
        
        // 读取10字节数据
        ret = i2c_master_receive(dev_handle, buf, sizeof(buf), -1);
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "Failed to read data: %s", esp_err_to_name(ret));
            i2c_master_bus_rm_device(dev_handle);
            return ;
        }
        
        if (buf[8] == 32) {
            GUI_Value_X = buf[4] | ((buf[7] & 0x0f) << 8);  // x坐标
            GUI_Value_Y = buf[5] | ((buf[7] & 0xF0) << 4);  // y坐标
            touchInfo_flag = 1;  // 触摸有效
        } else {
            touchInfo_flag = 0;  // 触摸无效
        }

        //ESP_LOGI(TAG, "%d %d",GUI_Value_X, GUI_Value_Y);
        
        // 写入结束命令
        uint8_t end_data[4] = {0xD0, 0x00, 0x02, 0xAB};
        ret = i2c_master_transmit(dev_handle, end_data, sizeof(end_data), -1);
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "Failed to write end command: %s", esp_err_to_name(ret));
        }
        
        if (touchInfo_flag) {
            data->point.x = GUI_Value_X;
            data->point.y = GUI_Value_Y;
            data->state = LV_INDEV_STATE_PR;
        } else {
            data->state = LV_INDEV_STATE_REL;
        }

    //    touch_event_occurred = false;  // 清除标志
    //}
    
}

//自动扫码I2C地址
void i2c_scan() {
    printf("\nScanning I2C bus...\n");
    for (uint8_t addr = 0x08; addr <= 0x77; addr++) {
        esp_err_t ret = i2c_master_probe(bus_handle, addr, pdMS_TO_TICKS(100));
        if (ret == ESP_OK) {
            printf("Found device at: 0x%02X\n", addr);
        }
    }
}

void app_main(void)
{
    ws2812_init(WS2812_GPIO_NUM,WS2812_LED_NUM,&ws2812_handle);
    
    /* 初始化 Wi-Fi */
    wifi_sta_init();

    /* led灯初始化 */
    //gpio_set_direction(GPIO_NUM_38, GPIO_MODE_OUTPUT);gpio_set_level(GPIO_NUM_38 , 0);

    static lv_disp_draw_buf_t disp_buf; // contains internal graphic buffer(s) called draw buffer(s)
    static lv_disp_drv_t disp_drv;      // contains callback functions

#if CONFIG_EXAMPLE_AVOID_TEAR_EFFECT_WITH_SEM
    ESP_LOGI(TAG, "Create semaphores");
    sem_vsync_end = xSemaphoreCreateBinary();
    assert(sem_vsync_end);
    sem_gui_ready = xSemaphoreCreateBinary();
    assert(sem_gui_ready);
#endif
    
#if EXAMPLE_PIN_NUM_BK_LIGHT >= 0
    ESP_LOGI(TAG, "Turn off LCD backlight");
    gpio_config_t bk_gpio_config = {
        .mode = GPIO_MODE_OUTPUT,
        .pin_bit_mask = 1ULL << EXAMPLE_PIN_NUM_BK_LIGHT
    };
    ESP_ERROR_CHECK(gpio_config(&bk_gpio_config));
#endif
    
    ESP_LOGI(TAG, "Install RGB LCD panel driver");
    esp_lcd_panel_handle_t panel_handle = NULL;
    //ESP_ERROR_CHECK(esp_lcd_panel_reset(panel_handle));
   
    Lcd_Initialize();
    esp_lcd_rgb_panel_config_t panel_config = {
        .data_width = 16, // RGB565 in parallel mode, thus 16bit in width
        .psram_trans_align = 64,
        .num_fbs = EXAMPLE_LCD_NUM_FB,
#if CONFIG_EXAMPLE_USE_BOUNCE_BUFFER
        .bounce_buffer_size_px = 10 * EXAMPLE_LCD_H_RES,
#endif
        .clk_src = LCD_CLK_SRC_PLL240M,
        .disp_gpio_num = EXAMPLE_PIN_NUM_DISP_EN,
        .pclk_gpio_num = EXAMPLE_PIN_NUM_PCLK,
        .vsync_gpio_num = EXAMPLE_PIN_NUM_VSYNC,
        .hsync_gpio_num = EXAMPLE_PIN_NUM_HSYNC,
        .de_gpio_num = EXAMPLE_PIN_NUM_DE,
        .data_gpio_nums = {
            EXAMPLE_PIN_NUM_DATA0,
            EXAMPLE_PIN_NUM_DATA1,
            EXAMPLE_PIN_NUM_DATA2,
            EXAMPLE_PIN_NUM_DATA3,
            EXAMPLE_PIN_NUM_DATA4,
            EXAMPLE_PIN_NUM_DATA5,
            EXAMPLE_PIN_NUM_DATA6,
            EXAMPLE_PIN_NUM_DATA7,
            EXAMPLE_PIN_NUM_DATA8,
            EXAMPLE_PIN_NUM_DATA9,
            EXAMPLE_PIN_NUM_DATA10,
            EXAMPLE_PIN_NUM_DATA11,
            EXAMPLE_PIN_NUM_DATA12,
            EXAMPLE_PIN_NUM_DATA13,
            EXAMPLE_PIN_NUM_DATA14,
            EXAMPLE_PIN_NUM_DATA15,
        },
        .timings = {
            .pclk_hz = EXAMPLE_LCD_PIXEL_CLOCK_HZ,
            .h_res = EXAMPLE_LCD_H_RES,
            .v_res = EXAMPLE_LCD_V_RES,
            // The following parameters should refer to LCD spec
            .hsync_back_porch = 9,
            .hsync_front_porch = 4,
            .hsync_pulse_width = 2,

            .vsync_back_porch = 9,
            .vsync_front_porch = 4,
            .vsync_pulse_width = 2,
            .flags.pclk_active_neg = true,
        },
        .flags.fb_in_psram = true, // allocate frame buffer in PSRAM
    };
    ESP_ERROR_CHECK(esp_lcd_new_rgb_panel(&panel_config, &panel_handle));

    ESP_LOGI(TAG, "Register event callbacks");
    esp_lcd_rgb_panel_event_callbacks_t cbs = {
        .on_vsync = example_on_vsync_event,
    };
    ESP_ERROR_CHECK(esp_lcd_rgb_panel_register_event_callbacks(panel_handle, &cbs, &disp_drv));

    ESP_LOGI(TAG, "Initialize RGB LCD panel");
    
    ESP_ERROR_CHECK(esp_lcd_panel_init(panel_handle));

#if EXAMPLE_PIN_NUM_BK_LIGHT >= 0
    ESP_LOGI(TAG, "Turn on LCD backlight");
    gpio_set_level(EXAMPLE_PIN_NUM_BK_LIGHT, EXAMPLE_LCD_BK_LIGHT_ON_LEVEL);
#endif

    ESP_LOGI(TAG, "Initialize LVGL library");
    lv_init();
    void *buf1 = NULL;
    void *buf2 = NULL;
#if CONFIG_EXAMPLE_DOUBLE_FB
    ESP_LOGI(TAG, "Use frame buffers as LVGL draw buffers");
    ESP_ERROR_CHECK(esp_lcd_rgb_panel_get_frame_buffer(panel_handle, 2, &buf1, &buf2));
    // initialize LVGL draw buffers
    lv_disp_draw_buf_init(&disp_buf, buf1, buf2, EXAMPLE_LCD_H_RES * EXAMPLE_LCD_V_RES);
#else
    ESP_LOGI(TAG, "Allocate separate LVGL draw buffers from PSRAM");
    buf1 = heap_caps_malloc(EXAMPLE_LCD_H_RES * EXAMPLE_LCD_V_RES * sizeof(lv_color_t), MALLOC_CAP_SPIRAM);
    assert(buf1);
    // initialize LVGL draw buffers
    lv_disp_draw_buf_init(&disp_buf, buf1, buf2, EXAMPLE_LCD_H_RES * EXAMPLE_LCD_V_RES);
#endif // CONFIG_EXAMPLE_DOUBLE_FB

    ESP_LOGI(TAG, "Register display driver to LVGL");
    lv_disp_drv_init(&disp_drv);
    disp_drv.hor_res = EXAMPLE_LCD_H_RES;
    disp_drv.ver_res = EXAMPLE_LCD_V_RES;
    disp_drv.flush_cb = example_lvgl_flush_cb;
    disp_drv.draw_buf = &disp_buf;
    disp_drv.user_data = panel_handle;
#if CONFIG_EXAMPLE_DOUBLE_FB
    disp_drv.full_refresh = true; // the full_refresh mode can maintain the synchronization between the two frame buffers
#endif
    lv_disp_t *disp = lv_disp_drv_register(&disp_drv);

    ESP_LOGI(TAG, "Install LVGL tick timer");
    // Tick interface for LVGL (using esp_timer to generate 2ms periodic event)
    const esp_timer_create_args_t lvgl_tick_timer_args = {
        .callback = &example_increase_lvgl_tick,
        .name = "lvgl_tick"
    };
    esp_timer_handle_t lvgl_tick_timer = NULL;
    ESP_ERROR_CHECK(esp_timer_create(&lvgl_tick_timer_args, &lvgl_tick_timer));
    ESP_ERROR_CHECK(esp_timer_start_periodic(lvgl_tick_timer, EXAMPLE_LVGL_TICK_PERIOD_MS * 1000));



    /* 初始化触摸控制器 */
    ESP_LOGI(TAG, "初始化触摸控制器");
    ESP_ERROR_CHECK(app_touch_init());


//i2c_scan();  // 扫描并打印所有设备


    /* 注册触摸设备到 LVGL */
    ESP_LOGI(TAG, "注册触摸设备到 LVGL");
    static lv_indev_drv_t indev_drv;
    lv_indev_drv_init(&indev_drv);
    indev_drv.type = LV_INDEV_TYPE_POINTER;  // 触摸屏属于指针输入设备
    indev_drv.read_cb = example_lvgl_touch_cb; // 设置触摸回调
    //indev_drv.user_data = touch_handle;       // 传递触摸句柄

    /* 注册输入设备 */
    lv_indev_t *touch_indev = lv_indev_drv_register(&indev_drv);

    init_touch_interrupt();     // 中断初始化

    lvgl_mux = xSemaphoreCreateRecursiveMutex();
    assert(lvgl_mux);
    ESP_LOGI(TAG, "Create LVGL task");
    xTaskCreate(example_lvgl_port_task, "LVGL", EXAMPLE_LVGL_TASK_STACK_SIZE, NULL, EXAMPLE_LVGL_TASK_PRIORITY, NULL);

    ESP_LOGI(TAG, "Display LVGL Scatter Chart");
    // Lock the mutex due to the LVGL APIs are not thread-safe
    if (example_lvgl_lock(-1)) {
        /* 加载中（动图） */
        // ui_gif_demo();

        /* 菜单 */
        lvgl_demo_ui(disp);

        // Release the mutex
        example_lvgl_unlock();
    }
}
